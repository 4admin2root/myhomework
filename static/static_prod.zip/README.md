# static files
## This is  a demo of static file.
It is bad way to manage static files by scm.
### docker run --name nginx -v $PWD/static:/usr/share/nginx/html:ro -p 80:80 -d nginx
